import os, io, csv, re, random, datetime as dt
import bcrypt, jwt
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from sqlalchemy.orm import Session
from .models import Base, engine, get_db, User, Tx, Budget, Goal
from . import ml

SECRET = os.getenv("JWT_SECRET", "change-me")
app = FastAPI(title="SmartFin AI")

cors_origins_env = os.getenv("CORS_ORIGINS", "")
if cors_origins_env.strip() == "*":
    origins = ["*"]
    allow_credentials = False
elif cors_origins_env.strip():
    origins = [orig.strip() for orig in cors_origins_env.split(",") if orig.strip()]
    allow_credentials = True
else:
    origins = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]
    allow_credentials = True

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_origin_regex=os.getenv("CORS_ORIGIN_REGEX", r"^https:\/\/.*\.onrender\.com$") if origins != ["*"] else None,
    allow_credentials=allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)
Base.metadata.create_all(engine)
bearer = HTTPBearer()

@app.get("/health")
def health():
    return {"status": "ok", "service": "SmartFin AI API"}


class Cred(BaseModel): email: str; password: str
class TxIn(BaseModel): date: dt.date; merchant: str; amount: float; type: str; category: str | None = None
class Afford(BaseModel): price: float
class Twin(BaseModel): income_change: float = 0; expense_change: float = 0; extra_saving: float = 0; purchase: float = 0
class Msg(BaseModel): message: str
class Amt(BaseModel): amount: float
class GoalIn(BaseModel): name: str; target: float
class Settings(BaseModel): low_balance: float

def token(u): return jwt.encode({"sub": str(u.id), "exp": dt.datetime.utcnow() + dt.timedelta(days=7)}, SECRET, "HS256")

def me(c: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)):
    try:
        uid = int(jwt.decode(c.credentials, SECRET, algorithms=["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Invalid or expired token")
    u = db.get(User, uid)
    if not u: raise HTTPException(401, "Unknown user")
    return u

def txs(db, u): return db.query(Tx).filter(Tx.user_id == u.id).order_by(Tx.date.desc()).all()
def budgets(db, u): return {b.category: float(b.limit) for b in db.query(Budget).filter(Budget.user_id == u.id)}

@app.post("/auth/register")
def register(c: Cred, db: Session = Depends(get_db)):
    if len(c.password) < 8: raise HTTPException(400, "Password must be at least 8 characters")
    if db.query(User).filter(User.email == c.email.lower()).first(): raise HTTPException(400, "Email already registered")
    u = User(email=c.email.lower(), password_hash=bcrypt.hashpw(c.password.encode(), bcrypt.gensalt()).decode())
    db.add(u); db.commit()
    return {"token": token(u)}

@app.post("/auth/login")
def login(c: Cred, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email == c.email.lower()).first()
    if not u or not bcrypt.checkpw(c.password.encode(), u.password_hash.encode()): raise HTTPException(401, "Wrong email or password")
    return {"token": token(u)}

@app.get("/me")
def profile(u: User = Depends(me)): return {"email": u.email, "low_balance": float(u.low_balance)}

@app.put("/me")
def settings(s: Settings, u: User = Depends(me), db: Session = Depends(get_db)):
    u.low_balance = s.low_balance; db.commit(); return {"ok": True}

@app.delete("/me")
def delete_account(u: User = Depends(me), db: Session = Depends(get_db)):
    for m in (Tx, Budget, Goal): db.query(m).filter(m.user_id == u.id).delete()
    db.delete(u); db.commit(); return {"deleted": True}

@app.get("/transactions")
def list_tx(u: User = Depends(me), db: Session = Depends(get_db)):
    return [{"id": x.id, "date": str(x.date), "merchant": x.merchant, "amount": float(x.amount), "type": x.type, "category": x.category} for x in txs(db, u)]

@app.post("/transactions")
def add_tx(t: TxIn, u: User = Depends(me), db: Session = Depends(get_db)):
    if t.amount <= 0 or t.type not in ("in", "out"): raise HTTPException(400, "Amount must be positive and type 'in' or 'out'")
    hist = [(x.merchant, x.category) for x in txs(db, u) if x.type == "out"]
    c = t.category if t.category and t.type == "out" else ml.categorize(t.merchant, t.type, hist)
    db.add(Tx(user_id=u.id, date=t.date, merchant=t.merchant, amount=round(t.amount, 2), type=t.type, category=c)); db.commit()
    return {"category": c}

@app.delete("/transactions/{tid}")
def del_tx(tid: int, u: User = Depends(me), db: Session = Depends(get_db)):
    db.query(Tx).filter(Tx.id == tid, Tx.user_id == u.id).delete(); db.commit(); return {"ok": True}

@app.post("/receipts/scan")
async def scan(file: UploadFile = File(...), u: User = Depends(me)):
    try:
        import pytesseract; from PIL import Image
        text = pytesseract.image_to_string(Image.open(io.BytesIO(await file.read())))
    except Exception as e:
        raise HTTPException(501, f"OCR unavailable (install Tesseract): {e}")
    nums = [float(n.replace(",", "")) for n in re.findall(r"(\d[\d,]*\.\d{2})", text)]
    return {"amount": max(nums) if nums else None, "merchant": (text.strip().splitlines() or [""])[0][:40], "raw": text[:500]}

@app.get("/analytics/summary")
def summary(u: User = Depends(me), db: Session = Depends(get_db)):
    t = txs(db, u); mo = ml.monthly(t); bal = ml.balance(t); ks = sorted(mo)[-6:]
    last3 = ml.done(mo)[-3:]; cats = {}
    for k in last3:
        for c, v in mo[k]["cat"].items(): cats[c] = cats.get(c, 0) + v
    cur = mo.get(ml.cur_key(), {"in": 0, "out": 0})
    return {"balance": bal, "low_balance_alert": bal < float(u.low_balance), "threshold": float(u.low_balance),
            "months": [{"month": k, "income": mo[k]["in"], "expense": mo[k]["out"]} for k in ks],
            "categories": [{"name": c, "value": round(v)} for c, v in sorted(cats.items(), key=lambda x: -x[1])],
            "current": {"income": cur["in"], "expense": cur["out"]},
            "forecast": ml.forecast(mo), "health": ml.health(mo, bal, budgets(db, u))}

@app.get("/analytics/insights")
def insights(u: User = Depends(me), db: Session = Depends(get_db)):
    t = txs(db, u); return {"anomalies": ml.anomalies(t), "subscriptions": ml.subscriptions(t), "transaction_count": len(t)}

@app.post("/simulate/afford")
def sim_afford(a: Afford, u: User = Depends(me), db: Session = Depends(get_db)):
    t = txs(db, u); return ml.afford(ml.monthly(t), ml.balance(t), a.price)

@app.post("/simulate/twin")
def sim_twin(s: Twin, u: User = Depends(me), db: Session = Depends(get_db)):
    t = txs(db, u); return ml.twin(ml.monthly(t), ml.balance(t), s.income_change, s.expense_change, s.extra_saving, s.purchase)

@app.get("/budgets")
def get_budgets(u: User = Depends(me), db: Session = Depends(get_db)):
    mo = ml.monthly(txs(db, u)); b = budgets(db, u); d = ml.done(mo)[-3:]; spent = mo.get(ml.cur_key(), {"cat": {}})["cat"]; out = []
    for c in ml.CATS:
        sug = round(sum(mo[k]["cat"].get(c, 0) for k in d) / len(d) * 0.95 / 100) * 100 if len(d) >= 2 else None
        out.append({"category": c, "limit": b.get(c), "spent": spent.get(c, 0), "suggested": sug,
                    "why": f"95% of your {len(d)}-month average." if sug else "Needs 2+ complete months."})
    return out

@app.put("/budgets/{cat}")
def set_budget(cat: str, a: Amt, u: User = Depends(me), db: Session = Depends(get_db)):
    db.query(Budget).filter(Budget.user_id == u.id, Budget.category == cat).delete()
    if a.amount > 0: db.add(Budget(user_id=u.id, category=cat, limit=a.amount))
    db.commit(); return {"ok": True}

@app.get("/goals")
def get_goals(u: User = Depends(me), db: Session = Depends(get_db)):
    return [{"id": g.id, "name": g.name, "target": float(g.target), "saved": float(g.saved)} for g in db.query(Goal).filter(Goal.user_id == u.id)]

@app.post("/goals")
def add_goal(g: GoalIn, u: User = Depends(me), db: Session = Depends(get_db)):
    db.add(Goal(user_id=u.id, name=g.name, target=g.target, saved=0)); db.commit(); return {"ok": True}

@app.post("/goals/{gid}/contribute")
def contribute(gid: int, a: Amt, u: User = Depends(me), db: Session = Depends(get_db)):
    g = db.query(Goal).filter(Goal.id == gid, Goal.user_id == u.id).first()
    if not g: raise HTTPException(404, "Goal not found")
    g.saved = float(g.saved) + a.amount; db.commit(); return {"ok": True}

@app.post("/chat")
def chat(m: Msg, u: User = Depends(me), db: Session = Depends(get_db)):
    t = txs(db, u); mo = ml.monthly(t); l = m.message.lower()
    hi = bool(re.search(r"[\u0900-\u097F]|kitna|kharch|bachat|mera|paisa|kya|kitni", l))
    T = lambda e, h: h if hi else e
    if not t: return {"reply": T("No data yet. Add transactions first.", "Abhi data nahi hai. Pehle transactions add karein.")}
    cur = mo.get(ml.cur_key(), {"in": 0, "out": 0, "cat": {}}); R = lambda n: f"₹{n:,.0f}"
    alias = {"food": "Food", "khana": "Food", "swiggy": "Food", "grocer": "Groceries", "transport": "Transport", "shopping": "Shopping", "rent": "Rent", "health": "Health", "bill": "Bills"}
    for k, c in alias.items():
        if k in l:
            d = ml.done(mo)[-3:]; avg = sum(mo[x]["cat"].get(c, 0) for x in d) / max(1, len(d))
            return {"reply": T(f"{c}: {R(cur['cat'].get(c, 0))} this month; 3-month average {R(avg)}.", f"{c} par is mahine {R(cur['cat'].get(c, 0))} kharch hua; 3 mahine ka average {R(avg)}.")}
    if re.search(r"balance|paisa|बैलेंस", l): return {"reply": T(f"Your balance is {R(ml.balance(t))}.", f"Aapka balance {R(ml.balance(t))} hai.")}
    if re.search(r"forecast|predict|agle|अनुमान", l):
        f = ml.forecast(mo)
        return {"reply": T(f"Expected spend this month: {R(f['predicted'])}.", f"Is mahine ka expected kharcha {R(f['predicted'])} hai.") if f["ok"] else T(f["reason"], "Forecast ke liye kam se kam 3 poore mahine ka data chahiye.")}
    if re.search(r"subscri|recurring", l):
        s = ml.subscriptions(t); return {"reply": ", ".join(f"{x['merchant']} {R(x['monthly'])}" for x in s) or T("No subscriptions detected.", "Koi subscription nahi mila.")}
    if re.search(r"save|saving|bachat|बचत|health", l):
        h = ml.health(mo, ml.balance(t), budgets(db, u))
        return {"reply": T(f"Savings rate {h['savings_rate']*100:.0f}%, health score {h['score']}/100.", f"Bachat dar {h['savings_rate']*100:.0f}%, health score {h['score']}/100.") if h["ok"] else T(h["reason"], "Score ke liye data kam hai.")}
    if re.search(r"spen|kharch|खर्च|expense", l): return {"reply": T(f"You spent {R(cur['out'])} and earned {R(cur['in'])} this month.", f"Is mahine aapne {R(cur['out'])} kharch kiye aur {R(cur['in'])} kamaye.")}
    return {"reply": T("Ask about spending by category, balance, forecast, savings or subscriptions.", "Kharcha, balance, forecast, bachat ya subscriptions ke baare mein poochiye.")}

@app.get("/export/csv", response_class=PlainTextResponse)
def export(u: User = Depends(me), db: Session = Depends(get_db)):
    o = io.StringIO(); w = csv.writer(o); w.writerow(["date", "merchant", "category", "type", "amount"])
    for x in txs(db, u): w.writerow([x.date, x.merchant, x.category, x.type, x.amount])
    return o.getvalue()

@app.post("/demo/seed")
def seed(u: User = Depends(me), db: Session = Depends(get_db)):
    r = random.Random(7); today = dt.date.today(); M = [("Swiggy", 350, 700), ("Zomato", 300, 650), ("DMart", 1200, 2500), ("Uber", 150, 450), ("Amazon", 500, 3000), ("Apollo Pharmacy", 200, 900), ("BookMyShow", 300, 800)]
    for i in range(5, -1, -1):
        y, mth = today.year, today.month - i
        while mth < 1: mth += 12; y -= 1
        def add(day, mer, amt, ty="out"):
            d = dt.date(y, mth, day)
            if d <= today: db.add(Tx(user_id=u.id, date=d, merchant=mer, amount=round(amt, 2), type=ty, category=ml.categorize(mer, ty)))
        add(1, "Salary Infosys", 85000, "in"); add(2, "House Rent", 22000); add(5, "Netflix", 649); add(6, "Spotify", 119); add(8, "Gold Gym", 1500); add(10, "Electricity MSEDCL", 1400 + r.random() * 600)
        for _ in range(11):
            m = r.choice(M); add(3 + r.randrange(25), m[0], m[1] + r.random() * (m[2] - m[1]))
        if i == 1: add(15, "Myntra", 14500)
    db.commit(); return {"ok": True}

from pathlib import Path
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

dist_candidates = [
    Path(__file__).resolve().parent.parent.parent / "frontend" / "dist",
    Path(__file__).resolve().parent.parent / "frontend" / "dist",
    Path(__file__).resolve().parent.parent / "dist",
]
frontend_dist = next((p for p in dist_candidates if p.exists()), None)

if frontend_dist:
    assets_dir = frontend_dist / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}")
    def serve_frontend(full_path: str):
        target = frontend_dist / full_path
        if full_path and target.is_file():
            return FileResponse(str(target))
        return FileResponse(str(frontend_dist / "index.html"))

