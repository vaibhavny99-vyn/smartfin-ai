import re
from collections import defaultdict
from datetime import date
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

CATS = ["Food", "Groceries", "Transport", "Bills", "Rent", "Subscriptions", "Shopping", "Health", "Entertainment", "Other"]
KW = [(r"swiggy|zomato|restaurant|cafe|dominos", "Food"), (r"grocery|bazaar|bigbasket|dmart|blinkit", "Groceries"),
      (r"uber|ola|metro|petrol|irctc", "Transport"), (r"electric|recharge|jio|airtel|broadband|water", "Bills"),
      (r"rent", "Rent"), (r"netflix|spotify|prime|gym|hotstar", "Subscriptions"), (r"amazon|myntra|flipkart|ajio", "Shopping"),
      (r"pharmacy|apollo|clinic|hospital", "Health"), (r"bookmyshow|movie|pvr", "Entertainment")]

def categorize(merchant, ty, history=()):
    """Keyword rules first; then a Naive Bayes model learned from the user's own labelled history."""
    if ty == "in":
        return "Income"
    for rx, c in KW:
        if re.search(rx, merchant, re.I):
            return c
    if len(history) >= 30 and len({c for _, c in history}) > 1:
        X, y = zip(*history)
        p = make_pipeline(TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4)), MultinomialNB()).fit(X, y)
        return p.predict([merchant])[0]
    return "Other"

def cur_key():
    return date.today().strftime("%Y-%m")

def monthly(txs):
    mo = defaultdict(lambda: {"in": 0.0, "out": 0.0, "cat": defaultdict(float)})
    for x in txs:
        k, a = x.date.strftime("%Y-%m"), float(x.amount)
        if x.type == "in":
            mo[k]["in"] += a
        else:
            mo[k]["out"] += a
            mo[k]["cat"][x.category] += a
    return mo

def done(mo):
    return [k for k in sorted(mo) if k < cur_key()]

def balance(txs):
    return round(sum(float(x.amount) if x.type == "in" else -float(x.amount) for x in txs), 2)

def baseline(mo):
    d = done(mo)[-3:]
    return (float(np.mean([mo[k]["in"] for k in d])), float(np.mean([mo[k]["out"] for k in d]))) if d else (0.0, 0.0)

def forecast(mo):
    d = done(mo)
    if len(d) < 3:
        return {"ok": False, "reason": "Need at least 3 complete months of data to forecast."}
    y = np.array([mo[k]["out"] for k in d])
    m = LinearRegression().fit(np.arange(len(y)).reshape(-1, 1), y)
    return {"ok": True, "predicted": round(max(0.0, float(m.predict([[len(y)]])[0])), 2),
            "trend_per_month": round(float(m.coef_[0]), 2), "months_used": len(y),
            "explanation": f"Linear trend fitted on {len(y)} months of spending."}

def anomalies(txs):
    g, out = defaultdict(list), []
    for x in txs:
        if x.type == "out":
            g[x.category].append(x)
    for c, a in g.items():
        if len(a) < 8:
            continue
        v = np.array([[float(x.amount)] for x in a])
        med = float(np.median(v))
        pred = IsolationForest(contamination=0.05, random_state=0).fit(v).predict(v)
        for x, p in zip(a, pred):
            if p == -1 and float(x.amount) > 2 * med:
                out.append({"id": x.id, "date": str(x.date), "merchant": x.merchant, "category": c, "amount": float(x.amount),
                            "reason": f"{float(x.amount) / med:.1f}x your typical {c} transaction (₹{med:,.0f})."})
    return out

def subscriptions(txs):
    g = defaultdict(list)
    for x in txs:
        if x.type == "out":
            g[x.merchant].append(x)
    out = []
    for m, a in g.items():
        months = {x.date.strftime("%Y-%m") for x in a}
        v = [float(x.amount) for x in a]
        if len(months) >= 3 and len(months) == len(a) and max(v) <= min(v) * 1.35:
            out.append({"merchant": m, "monthly": round(float(np.mean(v)), 2), "months_seen": len(months)})
    return out

def health(mo, bal, budgets):
    d = done(mo)[-3:]
    inc, exp = baseline(mo)
    if len(d) < 2 or inc <= 0:
        return {"ok": False, "reason": "Need 2+ complete months with income to score."}
    sr = (inc - exp) / inc
    s1 = max(0, min(40, sr / 0.3 * 40))
    spent = mo.get(cur_key(), {"cat": {}})["cat"]
    s2 = 30 * float(np.mean([spent.get(c, 0) <= l for c, l in budgets.items()])) if budgets else 15
    em = max(0, bal) / exp if exp else 0
    s3 = min(30, em / 6 * 30)
    return {"ok": True, "score": round(s1 + s2 + s3), "savings_rate": round(sr, 3), "emergency_months": round(em, 1),
            "breakdown": {"savings_rate": round(s1), "budget_adherence": round(s2), "emergency_fund": round(s3)}}

def afford(mo, bal, price):
    f = forecast(mo)
    if not f["ok"]:
        return {"ok": False, "reason": f["reason"]}
    left = max(0, f["predicted"] - mo.get(cur_key(), {"out": 0})["out"])
    after = bal - left - price
    buf = 3 * baseline(mo)[1]
    v = "no" if after < 0 else "risky" if after < buf else "yes"
    return {"ok": True, "verdict": v, "balance_after": round(after, 2), "safety_buffer": round(buf, 2),
            "explanation": f"Balance after remaining expected spend (₹{left:,.0f}) and this purchase: ₹{after:,.0f}; 3-month buffer is ₹{buf:,.0f}."}

def twin(mo, bal, ic, ec, xs, pu):
    if len(done(mo)) < 3:
        return {"ok": False, "reason": "Need 3+ complete months to build a baseline."}
    inc, exp = baseline(mo)
    a, c = [bal], [bal - pu]
    for _ in range(12):
        a.append(a[-1] + inc - exp)
        c.append(c[-1] + inc * (1 + ic / 100) - exp * (1 + ec / 100) - xs)
    return {"ok": True, "baseline": [round(v) for v in a], "scenario": [round(v) for v in c], "income": round(inc), "expense": round(exp)}
