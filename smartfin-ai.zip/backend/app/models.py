import os
from sqlalchemy import create_engine, Column, Integer, String, Numeric, Date, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

URL = os.getenv("DATABASE_URL")
connect_args = {}

if URL:
    if URL.startswith("postgres://"):
        URL = URL.replace("postgres://", "postgresql+psycopg2://", 1)
    elif URL.startswith("postgresql://") and "+psycopg2" not in URL:
        URL = URL.replace("postgresql://", "postgresql+psycopg2://", 1)

    if URL.startswith("sqlite"):
        connect_args = {"check_same_thread": False}
    engine = create_engine(URL, connect_args=connect_args)
else:
    try:
        test_url = "postgresql+psycopg2://smartfin:smartfin@localhost:5432/smartfin"
        test_engine = create_engine(test_url)
        with test_engine.connect():
            pass
        URL = test_url
        engine = test_engine
    except Exception:
        URL = "sqlite:///./smartfin.db"
        connect_args = {"check_same_thread": False}
        engine = create_engine(URL, connect_args=connect_args)

SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    low_balance = Column(Numeric(12, 2), default=10000)

class Tx(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    date = Column(Date, nullable=False)
    merchant = Column(String, nullable=False)
    amount = Column(Numeric(12, 2), nullable=False)
    type = Column(String, nullable=False)  # "in" | "out"
    category = Column(String, nullable=False)

class Budget(Base):
    __tablename__ = "budgets"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    category = Column(String, nullable=False)
    limit = Column(Numeric(12, 2), nullable=False)

class Goal(Base):
    __tablename__ = "goals"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name = Column(String, nullable=False)
    target = Column(Numeric(12, 2), nullable=False)
    saved = Column(Numeric(12, 2), default=0)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
