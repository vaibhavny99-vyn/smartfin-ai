import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";
import { api, post, tok } from "./api";

const inr = (n: number) => "₹" + Math.round(n || 0).toLocaleString("en-IN");
const inp = "rounded-lg border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-1.5";
const btn = "rounded-lg bg-indigo-600 text-white px-3 py-1.5 hover:bg-indigo-700";
const COLORS = ["#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981", "#06b6d4", "#64748b", "#ef4444"];
const Card = ({ t, children }: { t?: string; children: any }) => (
  <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 mb-4 shadow-sm">{t && <h3 className="font-semibold mb-2">{t}</h3>}{children}</div>
);
const Need = ({ r }: { r?: string }) => <p className="text-sm text-slate-500">Insufficient data: {r}</p>;

function Auth({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState("login"), [email, setEmail] = useState(""), [pw, setPw] = useState(""), [err, setErr] = useState("");
  const go = async () => { try { const r = await post(`/auth/${mode}`, { email, password: pw }); tok.set(r.token); onDone(); } catch (e: any) { setErr(e.message); } };
  return (
    <div className="max-w-sm mx-auto mt-24"><Card t={`SmartFin AI — ${mode === "login" ? "Sign in" : "Create account"}`}>
      <div className="flex flex-col gap-3">
        <input className={inp} placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className={inp} type="password" placeholder="Password (8+ chars)" value={pw} onChange={(e) => setPw(e.target.value)} />
        {err && <p className="text-red-500 text-sm">{err}</p>}
        <button className={btn} onClick={go}>{mode === "login" ? "Sign in" : "Register"}</button>
        <button className="text-sm text-indigo-500" onClick={() => setMode(mode === "login" ? "register" : "login")}>{mode === "login" ? "New here? Register" : "Have an account? Sign in"}</button>
      </div></Card></div>
  );
}

function Dashboard() {
  const [d, setD] = useState<any>(null);
  const load = () => api("/analytics/summary").then(setD);
  useEffect(() => { load(); }, []);
  if (!d) return <p>Loading…</p>;
  const h = d.health, f = d.forecast;
  return (<>
    {d.low_balance_alert && <div className="rounded-xl bg-red-100 text-red-700 p-3 mb-4">⚠ Low balance: {inr(d.balance)} is below {inr(d.threshold)}</div>}
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      {[["Balance", inr(d.balance)], ["Income (month)", inr(d.current.income)], ["Spent (month)", inr(d.current.expense)], ["Health score", h.ok ? h.score + "/100" : "—"]].map(([k, v]) =>
        <Card key={k}><div className="text-sm text-slate-500">{k}</div><div className="text-2xl font-bold">{v}</div></Card>)}
    </div>
    <div className="grid md:grid-cols-2 gap-4">
      <Card t="Income vs expenses"><div className="h-60"><ResponsiveContainer><BarChart data={d.months}><CartesianGrid strokeDasharray="3 3" opacity={0.3} /><XAxis dataKey="month" /><YAxis /><Tooltip formatter={(v: number) => inr(v)} /><Legend /><Bar dataKey="income" fill="#10b981" /><Bar dataKey="expense" fill="#6366f1" /></BarChart></ResponsiveContainer></div></Card>
      <Card t="Spending by category (3 months)"><div className="h-60"><ResponsiveContainer><PieChart><Pie data={d.categories} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} label>{d.categories.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip formatter={(v: number) => inr(v)} /></PieChart></ResponsiveContainer></div></Card>
    </div>
    <Card t="Forecast">{f.ok ? <p>Expected spend this month <b>{inr(f.predicted)}</b> <span className="text-sm text-slate-500">({f.explanation} Trend {inr(f.trend_per_month)}/month)</span></p> : <Need r={f.reason} />}</Card>
    <Card t="Financial health">{h.ok ? <p className="text-sm">Savings rate {Math.round(h.savings_rate * 100)}% → {h.breakdown.savings_rate}/40 · Budget adherence → {h.breakdown.budget_adherence}/30 · Emergency fund {h.emergency_months} months → {h.breakdown.emergency_fund}/30</p> : <Need r={h.reason} />}</Card>
    <button className={btn} onClick={async () => { await post("/demo/seed", {}); load(); }}>Load demo data</button>
  </>);
}

function Transactions() {
  const [rows, setRows] = useState<any[]>([]), [f, setF] = useState({ date: new Date().toISOString().slice(0, 10), merchant: "", amount: "", type: "out" }), [msg, setMsg] = useState("");
  const load = () => api("/transactions").then(setRows);
  useEffect(() => { load(); }, []);
  const add = async () => { try { const r = await post("/transactions", { ...f, amount: +f.amount }); setMsg("Categorised as " + r.category); setF({ ...f, merchant: "", amount: "" }); load(); } catch (e: any) { setMsg(e.message); } };
  const scan = async (file?: File) => { if (!file) return; const fd = new FormData(); fd.append("file", file); try { const r = await api("/receipts/scan", { method: "POST", body: fd }); setF({ ...f, amount: String(r.amount ?? ""), merchant: r.merchant || "" }); setMsg("Receipt scanned — check and save."); } catch (e: any) { setMsg(e.message); } };
  return (<>
    <Card t="Add transaction"><div className="flex flex-wrap gap-2">
      <input className={inp} type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
      <input className={inp} placeholder="Merchant" value={f.merchant} onChange={(e) => setF({ ...f, merchant: e.target.value })} />
      <input className={inp + " w-32"} type="number" placeholder="₹ Amount" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
      <select className={inp} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="out">Expense</option><option value="in">Income</option></select>
      <button className={btn} onClick={add}>Add</button>
      <label className={inp + " cursor-pointer"}>📷 Scan receipt<input type="file" accept="image/*" hidden onChange={(e) => scan(e.target.files?.[0])} /></label>
    </div>{msg && <p className="text-sm mt-2 text-slate-500">{msg}</p>}</Card>
    <Card><table className="w-full text-sm"><thead><tr className="text-left text-slate-500"><th>Date</th><th>Merchant</th><th>Category</th><th>Amount</th><th /></tr></thead>
      <tbody>{rows.slice(0, 80).map((x) => <tr key={x.id} className="border-t border-slate-200 dark:border-slate-700"><td>{x.date}</td><td>{x.merchant}</td><td>{x.category}</td><td className={x.type === "in" ? "text-emerald-500" : ""}>{x.type === "in" ? "+" : "−"}{inr(x.amount)}</td><td><button onClick={async () => { await api("/transactions/" + x.id, { method: "DELETE" }); load(); }}>✕</button></td></tr>)}</tbody></table></Card>
  </>);
}

function Insights() {
  const [d, setD] = useState<any>(null);
  useEffect(() => { api("/analytics/insights").then(setD); }, []);
  if (!d) return <p>Loading…</p>;
  return (<>
    <Card t="Unusual spending">{d.anomalies.length ? d.anomalies.map((a: any) => <p key={a.id}>⚠ <b>{a.merchant}</b> {inr(a.amount)} on {a.date} — {a.reason}</p>) : <p className="text-sm text-slate-500">Nothing unusual found (needs 8+ transactions per category).</p>}</Card>
    <Card t="Recurring payments & subscriptions">{d.subscriptions.length ? <>{d.subscriptions.map((s: any) => <p key={s.merchant}>{s.merchant}: ~{inr(s.monthly)}/month · seen {s.months_seen} months</p>)}<p className="text-sm text-slate-500 mt-2">Total {inr(d.subscriptions.reduce((a: number, s: any) => a + s.monthly, 0))}/month</p></> : <Need r="same merchant must appear in 3+ months." />}</Card>
  </>);
}

function Budgets() {
  const [b, setB] = useState<any[]>([]), [g, setG] = useState<any[]>([]), [n, setN] = useState(""), [t, setT] = useState("");
  const load = () => { api("/budgets").then(setB); api("/goals").then(setG); };
  useEffect(load, []);
  const set = async (c: string, v: number) => { await api("/budgets/" + c, { method: "PUT", body: JSON.stringify({ amount: v }) }); load(); };
  return (<>
    <Card t="Budgets (this month)">{b.map((x) => <div key={x.category} className="my-3"><div className="flex flex-wrap gap-2 items-center"><b className="w-28">{x.category}</b>
      <input className={inp + " w-28"} type="number" defaultValue={x.limit ?? ""} placeholder="Limit ₹" onBlur={(e) => set(x.category, +e.target.value)} />
      <span className="text-sm text-slate-500">{inr(x.spent)} spent</span>{x.suggested && <button className="text-indigo-500 text-sm" onClick={() => set(x.category, x.suggested)}>Suggest {inr(x.suggested)}</button>}</div>
      {x.limit && <div className="h-2 rounded bg-slate-200 dark:bg-slate-700 mt-1"><div className={"h-2 rounded " + (x.spent > x.limit ? "bg-red-500" : "bg-indigo-500")} style={{ width: Math.min(100, (x.spent / x.limit) * 100) + "%" }} /></div>}
      <p className="text-xs text-slate-500">{x.why}</p></div>)}</Card>
    <Card t="Savings goals">{g.map((x) => <div key={x.id} className="my-3"><b>{x.name}</b> <span className="text-sm text-slate-500">{inr(x.saved)} / {inr(x.target)}</span><div className="h-2 rounded bg-slate-200 dark:bg-slate-700"><div className="h-2 rounded bg-emerald-500" style={{ width: Math.min(100, (x.saved / x.target) * 100) + "%" }} /></div>
      <button className="text-sm text-indigo-500" onClick={async () => { const a = +(prompt("Amount to add (₹)") || 0); if (a > 0) { await post(`/goals/${x.id}/contribute`, { amount: a }); load(); } }}>+ Contribute</button></div>)}
      <div className="flex gap-2 mt-3"><input className={inp} placeholder="Goal name" value={n} onChange={(e) => setN(e.target.value)} /><input className={inp + " w-32"} type="number" placeholder="Target ₹" value={t} onChange={(e) => setT(e.target.value)} /><button className={btn} onClick={async () => { if (n && +t > 0) { await post("/goals", { name: n, target: +t }); setN(""); setT(""); load(); } }}>Add</button></div></Card>
  </>);
}

function Simulator() {
  const [price, setPrice] = useState(""), [res, setRes] = useState<any>(null), [s, setS] = useState({ income_change: 0, expense_change: 0, extra_saving: 0, purchase: 0 }), [tw, setTw] = useState<any>(null);
  useEffect(() => { post("/simulate/twin", s).then(setTw); }, [s]);
  const sl = (k: keyof typeof s, label: string, min: number, max: number, step: number) => <label className="text-sm block">{label}: <b>{s[k].toLocaleString("en-IN")}</b><input className="w-full" type="range" min={min} max={max} step={step} value={s[k]} onChange={(e) => setS({ ...s, [k]: +e.target.value })} /></label>;
  return (<>
    <Card t="Can I afford it?"><div className="flex gap-2"><input className={inp} type="number" placeholder="Price ₹" value={price} onChange={(e) => setPrice(e.target.value)} /><button className={btn} onClick={async () => setRes(await post("/simulate/afford", { price: +price }))}>Check</button></div>
      {res && (res.ok ? <p className="mt-2"><b className={res.verdict === "yes" ? "text-emerald-500" : res.verdict === "no" ? "text-red-500" : "text-amber-500"}>{res.verdict.toUpperCase()}</b> — {res.explanation}</p> : <div className="mt-2"><Need r={res.reason} /></div>)}</Card>
    <Card t="Financial Digital Twin (12 months)">{tw && !tw.ok ? <Need r={tw.reason} /> : <>
      <div className="grid md:grid-cols-2 gap-4">{sl("income_change", "Income change %", -30, 30, 1)}{sl("expense_change", "Expense change %", -30, 30, 1)}{sl("extra_saving", "Extra monthly saving ₹", 0, 30000, 1000)}{sl("purchase", "One-time purchase ₹", 0, 300000, 5000)}</div>
      {tw && <div className="h-64 mt-3"><ResponsiveContainer><LineChart data={tw.baseline.map((v: number, i: number) => ({ m: i, current: v, scenario: tw.scenario[i] }))}><CartesianGrid strokeDasharray="3 3" opacity={0.3} /><XAxis dataKey="m" /><YAxis /><Tooltip formatter={(v: number) => inr(v)} /><Legend /><Line dataKey="current" stroke="#94a3b8" dot={false} strokeWidth={2} /><Line dataKey="scenario" stroke="#6366f1" dot={false} strokeWidth={3} /></LineChart></ResponsiveContainer></div>}</>}</Card>
  </>);
}

function Assistant() {
  const [log, setLog] = useState<{ r: string; t: string }[]>([{ r: "a", t: 'Try: "How much did I spend on food?", "Mera balance kitna hai?", "forecast"' }]), [q, setQ] = useState(""), [lang, setLang] = useState("en-IN");
  const send = async (text: string) => {
    if (!text.trim()) return; setLog((l) => [...l, { r: "u", t: text }]); setQ("");
    const r = await post("/chat", { message: text }); setLog((l) => [...l, { r: "a", t: r.reply }]);
    try { const u = new SpeechSynthesisUtterance(r.reply); u.lang = lang; speechSynthesis.speak(u); } catch {}
  };
  const mic = () => { const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition; if (!SR) return alert("Voice input is not supported in this browser."); const r = new SR(); r.lang = lang; r.onresult = (e: any) => send(e.results[0][0].transcript); r.start(); };
  return (<Card t="AI financial assistant (English / हिन्दी / Hinglish)"><div className="h-80 overflow-y-auto flex flex-col gap-2 mb-3">{log.map((m, i) => <div key={i} className={"px-3 py-2 rounded-xl max-w-[85%] " + (m.r === "u" ? "self-end bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-700")}>{m.t}</div>)}</div>
    <div className="flex gap-2"><select className={inp} value={lang} onChange={(e) => setLang(e.target.value)}><option value="en-IN">English</option><option value="hi-IN">हिन्दी</option></select><button className={inp} onClick={mic}>🎤</button><input className={inp + " flex-1"} value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(q)} placeholder="Ask about your money…" /><button className={btn} onClick={() => send(q)}>Send</button></div></Card>);
}

function Settings({ onLogout }: { onLogout: () => void }) {
  const [p, setP] = useState<any>(null);
  useEffect(() => { api("/me").then(setP); }, []);
  const csv = async () => { const t = await api("/export/csv"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([t], { type: "text/csv" })); a.download = "smartfin.csv"; a.click(); };
  return (<>
    <Card t="Preferences">{p && <div className="flex gap-2 items-center">Low-balance alert ₹<input className={inp + " w-32"} type="number" defaultValue={p.low_balance} onBlur={(e) => api("/me", { method: "PUT", body: JSON.stringify({ low_balance: +e.target.value }) })} /></div>}<p className="text-sm text-slate-500 mt-2">Currency: INR (₹). Signed in as {p?.email}.</p></Card>
    <Card t="Reports"><button className={btn} onClick={csv}>Download CSV</button> <button className={btn} onClick={() => window.print()}>Print / Save as PDF</button></Card>
    <Card t="Account"><button className="rounded-lg border border-red-500 text-red-500 px-3 py-1.5" onClick={async () => { if (confirm("Permanently delete your account and all data?")) { await api("/me", { method: "DELETE" }); tok.clear(); onLogout(); } }}>Delete account & data</button></Card>
  </>);
}

const PAGES = ["Dashboard", "Transactions", "Insights", "Budgets", "Simulator", "Assistant", "Settings"];
export default function App() {
  const [authed, setAuthed] = useState(!!tok.get()), [page, setPage] = useState("Dashboard"), [dark, setDark] = useState(matchMedia("(prefers-color-scheme: dark)").matches);
  useEffect(() => { document.documentElement.classList.toggle("dark", dark); }, [dark]);
  if (!authed) return <Auth onDone={() => setAuthed(true)} />;
  const out = () => { tok.clear(); setAuthed(false); };
  return (<div className="max-w-5xl mx-auto p-4">
    <header className="flex items-center gap-3 mb-4 print:hidden"><span className="font-extrabold text-lg bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent">◆ SmartFin AI</span>
      <nav className="flex gap-1 overflow-x-auto flex-1">{PAGES.map((p) => <button key={p} onClick={() => setPage(p)} className={"px-3 py-1.5 rounded-lg whitespace-nowrap " + (page === p ? "bg-indigo-600 text-white" : "hover:bg-slate-200 dark:hover:bg-slate-700")}>{p}</button>)}</nav>
      <button onClick={() => setDark(!dark)}>◐</button><button className="text-sm" onClick={out}>Logout</button></header>
    {page === "Dashboard" && <Dashboard />}{page === "Transactions" && <Transactions />}{page === "Insights" && <Insights />}{page === "Budgets" && <Budgets />}{page === "Simulator" && <Simulator />}{page === "Assistant" && <Assistant />}{page === "Settings" && <Settings onLogout={out} />}
  </div>);
}
