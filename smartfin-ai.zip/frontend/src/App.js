import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";
import { api, post, tok } from "./api";
const inr = (n) => "₹" + Math.round(n || 0).toLocaleString("en-IN");
const inp = "rounded-lg border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-1.5";
const btn = "rounded-lg bg-indigo-600 text-white px-3 py-1.5 hover:bg-indigo-700";
const COLORS = ["#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981", "#06b6d4", "#64748b", "#ef4444"];
const Card = ({ t, children }) => (_jsxs("div", { className: "rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 mb-4 shadow-sm", children: [t && _jsx("h3", { className: "font-semibold mb-2", children: t }), children] }));
const Need = ({ r }) => _jsxs("p", { className: "text-sm text-slate-500", children: ["Insufficient data: ", r] });
function Auth({ onDone }) {
    const [mode, setMode] = useState("login"), [email, setEmail] = useState(""), [pw, setPw] = useState(""), [err, setErr] = useState("");
    const go = async () => { try {
        const r = await post(`/auth/${mode}`, { email, password: pw });
        tok.set(r.token);
        onDone();
    }
    catch (e) {
        setErr(e.message);
    } };
    return (_jsx("div", { className: "max-w-sm mx-auto mt-24", children: _jsx(Card, { t: `SmartFin AI — ${mode === "login" ? "Sign in" : "Create account"}`, children: _jsxs("div", { className: "flex flex-col gap-3", children: [_jsx("input", { className: inp, placeholder: "Email", value: email, onChange: (e) => setEmail(e.target.value) }), _jsx("input", { className: inp, type: "password", placeholder: "Password (8+ chars)", value: pw, onChange: (e) => setPw(e.target.value) }), err && _jsx("p", { className: "text-red-500 text-sm", children: err }), _jsx("button", { className: btn, onClick: go, children: mode === "login" ? "Sign in" : "Register" }), _jsx("button", { className: "text-sm text-indigo-500", onClick: () => setMode(mode === "login" ? "register" : "login"), children: mode === "login" ? "New here? Register" : "Have an account? Sign in" })] }) }) }));
}
function Dashboard() {
    const [d, setD] = useState(null);
    const load = () => api("/analytics/summary").then(setD);
    useEffect(() => { load(); }, []);
    if (!d)
        return _jsx("p", { children: "Loading\u2026" });
    const h = d.health, f = d.forecast;
    return (_jsxs(_Fragment, { children: [d.low_balance_alert && _jsxs("div", { className: "rounded-xl bg-red-100 text-red-700 p-3 mb-4", children: ["\u26A0 Low balance: ", inr(d.balance), " is below ", inr(d.threshold)] }), _jsx("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-4", children: [["Balance", inr(d.balance)], ["Income (month)", inr(d.current.income)], ["Spent (month)", inr(d.current.expense)], ["Health score", h.ok ? h.score + "/100" : "—"]].map(([k, v]) => _jsxs(Card, { children: [_jsx("div", { className: "text-sm text-slate-500", children: k }), _jsx("div", { className: "text-2xl font-bold", children: v })] }, k)) }), _jsxs("div", { className: "grid md:grid-cols-2 gap-4", children: [_jsx(Card, { t: "Income vs expenses", children: _jsx("div", { className: "h-60", children: _jsx(ResponsiveContainer, { children: _jsxs(BarChart, { data: d.months, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3", opacity: 0.3 }), _jsx(XAxis, { dataKey: "month" }), _jsx(YAxis, {}), _jsx(Tooltip, { formatter: (v) => inr(v) }), _jsx(Legend, {}), _jsx(Bar, { dataKey: "income", fill: "#10b981" }), _jsx(Bar, { dataKey: "expense", fill: "#6366f1" })] }) }) }) }), _jsx(Card, { t: "Spending by category (3 months)", children: _jsx("div", { className: "h-60", children: _jsx(ResponsiveContainer, { children: _jsxs(PieChart, { children: [_jsx(Pie, { data: d.categories, dataKey: "value", nameKey: "name", innerRadius: 50, outerRadius: 85, label: true, children: d.categories.map((_, i) => _jsx(Cell, { fill: COLORS[i % COLORS.length] }, i)) }), _jsx(Tooltip, { formatter: (v) => inr(v) })] }) }) }) })] }), _jsx(Card, { t: "Forecast", children: f.ok ? _jsxs("p", { children: ["Expected spend this month ", _jsx("b", { children: inr(f.predicted) }), " ", _jsxs("span", { className: "text-sm text-slate-500", children: ["(", f.explanation, " Trend ", inr(f.trend_per_month), "/month)"] })] }) : _jsx(Need, { r: f.reason }) }), _jsx(Card, { t: "Financial health", children: h.ok ? _jsxs("p", { className: "text-sm", children: ["Savings rate ", Math.round(h.savings_rate * 100), "% \u2192 ", h.breakdown.savings_rate, "/40 \u00B7 Budget adherence \u2192 ", h.breakdown.budget_adherence, "/30 \u00B7 Emergency fund ", h.emergency_months, " months \u2192 ", h.breakdown.emergency_fund, "/30"] }) : _jsx(Need, { r: h.reason }) }), _jsx("button", { className: btn, onClick: async () => { await post("/demo/seed", {}); load(); }, children: "Load demo data" })] }));
}
function Transactions() {
    const [rows, setRows] = useState([]), [f, setF] = useState({ date: new Date().toISOString().slice(0, 10), merchant: "", amount: "", type: "out" }), [msg, setMsg] = useState("");
    const load = () => api("/transactions").then(setRows);
    useEffect(() => { load(); }, []);
    const add = async () => { try {
        const r = await post("/transactions", { ...f, amount: +f.amount });
        setMsg("Categorised as " + r.category);
        setF({ ...f, merchant: "", amount: "" });
        load();
    }
    catch (e) {
        setMsg(e.message);
    } };
    const scan = async (file) => { if (!file)
        return; const fd = new FormData(); fd.append("file", file); try {
        const r = await api("/receipts/scan", { method: "POST", body: fd });
        setF({ ...f, amount: String(r.amount ?? ""), merchant: r.merchant || "" });
        setMsg("Receipt scanned — check and save.");
    }
    catch (e) {
        setMsg(e.message);
    } };
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { t: "Add transaction", children: [_jsxs("div", { className: "flex flex-wrap gap-2", children: [_jsx("input", { className: inp, type: "date", value: f.date, onChange: (e) => setF({ ...f, date: e.target.value }) }), _jsx("input", { className: inp, placeholder: "Merchant", value: f.merchant, onChange: (e) => setF({ ...f, merchant: e.target.value }) }), _jsx("input", { className: inp + " w-32", type: "number", placeholder: "\u20B9 Amount", value: f.amount, onChange: (e) => setF({ ...f, amount: e.target.value }) }), _jsxs("select", { className: inp, value: f.type, onChange: (e) => setF({ ...f, type: e.target.value }), children: [_jsx("option", { value: "out", children: "Expense" }), _jsx("option", { value: "in", children: "Income" })] }), _jsx("button", { className: btn, onClick: add, children: "Add" }), _jsxs("label", { className: inp + " cursor-pointer", children: ["\uD83D\uDCF7 Scan receipt", _jsx("input", { type: "file", accept: "image/*", hidden: true, onChange: (e) => scan(e.target.files?.[0]) })] })] }), msg && _jsx("p", { className: "text-sm mt-2 text-slate-500", children: msg })] }), _jsx(Card, { children: _jsxs("table", { className: "w-full text-sm", children: [_jsx("thead", { children: _jsxs("tr", { className: "text-left text-slate-500", children: [_jsx("th", { children: "Date" }), _jsx("th", { children: "Merchant" }), _jsx("th", { children: "Category" }), _jsx("th", { children: "Amount" }), _jsx("th", {})] }) }), _jsx("tbody", { children: rows.slice(0, 80).map((x) => _jsxs("tr", { className: "border-t border-slate-200 dark:border-slate-700", children: [_jsx("td", { children: x.date }), _jsx("td", { children: x.merchant }), _jsx("td", { children: x.category }), _jsxs("td", { className: x.type === "in" ? "text-emerald-500" : "", children: [x.type === "in" ? "+" : "−", inr(x.amount)] }), _jsx("td", { children: _jsx("button", { onClick: async () => { await api("/transactions/" + x.id, { method: "DELETE" }); load(); }, children: "\u2715" }) })] }, x.id)) })] }) })] }));
}
function Insights() {
    const [d, setD] = useState(null);
    useEffect(() => { api("/analytics/insights").then(setD); }, []);
    if (!d)
        return _jsx("p", { children: "Loading\u2026" });
    return (_jsxs(_Fragment, { children: [_jsx(Card, { t: "Unusual spending", children: d.anomalies.length ? d.anomalies.map((a) => _jsxs("p", { children: ["\u26A0 ", _jsx("b", { children: a.merchant }), " ", inr(a.amount), " on ", a.date, " \u2014 ", a.reason] }, a.id)) : _jsx("p", { className: "text-sm text-slate-500", children: "Nothing unusual found (needs 8+ transactions per category)." }) }), _jsx(Card, { t: "Recurring payments & subscriptions", children: d.subscriptions.length ? _jsxs(_Fragment, { children: [d.subscriptions.map((s) => _jsxs("p", { children: [s.merchant, ": ~", inr(s.monthly), "/month \u00B7 seen ", s.months_seen, " months"] }, s.merchant)), _jsxs("p", { className: "text-sm text-slate-500 mt-2", children: ["Total ", inr(d.subscriptions.reduce((a, s) => a + s.monthly, 0)), "/month"] })] }) : _jsx(Need, { r: "same merchant must appear in 3+ months." }) })] }));
}
function Budgets() {
    const [b, setB] = useState([]), [g, setG] = useState([]), [n, setN] = useState(""), [t, setT] = useState("");
    const load = () => { api("/budgets").then(setB); api("/goals").then(setG); };
    useEffect(load, []);
    const set = async (c, v) => { await api("/budgets/" + c, { method: "PUT", body: JSON.stringify({ amount: v }) }); load(); };
    return (_jsxs(_Fragment, { children: [_jsx(Card, { t: "Budgets (this month)", children: b.map((x) => _jsxs("div", { className: "my-3", children: [_jsxs("div", { className: "flex flex-wrap gap-2 items-center", children: [_jsx("b", { className: "w-28", children: x.category }), _jsx("input", { className: inp + " w-28", type: "number", defaultValue: x.limit ?? "", placeholder: "Limit \u20B9", onBlur: (e) => set(x.category, +e.target.value) }), _jsxs("span", { className: "text-sm text-slate-500", children: [inr(x.spent), " spent"] }), x.suggested && _jsxs("button", { className: "text-indigo-500 text-sm", onClick: () => set(x.category, x.suggested), children: ["Suggest ", inr(x.suggested)] })] }), x.limit && _jsx("div", { className: "h-2 rounded bg-slate-200 dark:bg-slate-700 mt-1", children: _jsx("div", { className: "h-2 rounded " + (x.spent > x.limit ? "bg-red-500" : "bg-indigo-500"), style: { width: Math.min(100, (x.spent / x.limit) * 100) + "%" } }) }), _jsx("p", { className: "text-xs text-slate-500", children: x.why })] }, x.category)) }), _jsxs(Card, { t: "Savings goals", children: [g.map((x) => _jsxs("div", { className: "my-3", children: [_jsx("b", { children: x.name }), " ", _jsxs("span", { className: "text-sm text-slate-500", children: [inr(x.saved), " / ", inr(x.target)] }), _jsx("div", { className: "h-2 rounded bg-slate-200 dark:bg-slate-700", children: _jsx("div", { className: "h-2 rounded bg-emerald-500", style: { width: Math.min(100, (x.saved / x.target) * 100) + "%" } }) }), _jsx("button", { className: "text-sm text-indigo-500", onClick: async () => { const a = +(prompt("Amount to add (₹)") || 0); if (a > 0) {
                                    await post(`/goals/${x.id}/contribute`, { amount: a });
                                    load();
                                } }, children: "+ Contribute" })] }, x.id)), _jsxs("div", { className: "flex gap-2 mt-3", children: [_jsx("input", { className: inp, placeholder: "Goal name", value: n, onChange: (e) => setN(e.target.value) }), _jsx("input", { className: inp + " w-32", type: "number", placeholder: "Target \u20B9", value: t, onChange: (e) => setT(e.target.value) }), _jsx("button", { className: btn, onClick: async () => { if (n && +t > 0) {
                                    await post("/goals", { name: n, target: +t });
                                    setN("");
                                    setT("");
                                    load();
                                } }, children: "Add" })] })] })] }));
}
function Simulator() {
    const [price, setPrice] = useState(""), [res, setRes] = useState(null), [s, setS] = useState({ income_change: 0, expense_change: 0, extra_saving: 0, purchase: 0 }), [tw, setTw] = useState(null);
    useEffect(() => { post("/simulate/twin", s).then(setTw); }, [s]);
    const sl = (k, label, min, max, step) => _jsxs("label", { className: "text-sm block", children: [label, ": ", _jsx("b", { children: s[k].toLocaleString("en-IN") }), _jsx("input", { className: "w-full", type: "range", min: min, max: max, step: step, value: s[k], onChange: (e) => setS({ ...s, [k]: +e.target.value }) })] });
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { t: "Can I afford it?", children: [_jsxs("div", { className: "flex gap-2", children: [_jsx("input", { className: inp, type: "number", placeholder: "Price \u20B9", value: price, onChange: (e) => setPrice(e.target.value) }), _jsx("button", { className: btn, onClick: async () => setRes(await post("/simulate/afford", { price: +price })), children: "Check" })] }), res && (res.ok ? _jsxs("p", { className: "mt-2", children: [_jsx("b", { className: res.verdict === "yes" ? "text-emerald-500" : res.verdict === "no" ? "text-red-500" : "text-amber-500", children: res.verdict.toUpperCase() }), " \u2014 ", res.explanation] }) : _jsx("div", { className: "mt-2", children: _jsx(Need, { r: res.reason }) }))] }), _jsx(Card, { t: "Financial Digital Twin (12 months)", children: tw && !tw.ok ? _jsx(Need, { r: tw.reason }) : _jsxs(_Fragment, { children: [_jsxs("div", { className: "grid md:grid-cols-2 gap-4", children: [sl("income_change", "Income change %", -30, 30, 1), sl("expense_change", "Expense change %", -30, 30, 1), sl("extra_saving", "Extra monthly saving ₹", 0, 30000, 1000), sl("purchase", "One-time purchase ₹", 0, 300000, 5000)] }), tw && _jsx("div", { className: "h-64 mt-3", children: _jsx(ResponsiveContainer, { children: _jsxs(LineChart, { data: tw.baseline.map((v, i) => ({ m: i, current: v, scenario: tw.scenario[i] })), children: [_jsx(CartesianGrid, { strokeDasharray: "3 3", opacity: 0.3 }), _jsx(XAxis, { dataKey: "m" }), _jsx(YAxis, {}), _jsx(Tooltip, { formatter: (v) => inr(v) }), _jsx(Legend, {}), _jsx(Line, { dataKey: "current", stroke: "#94a3b8", dot: false, strokeWidth: 2 }), _jsx(Line, { dataKey: "scenario", stroke: "#6366f1", dot: false, strokeWidth: 3 })] }) }) })] }) })] }));
}
function Assistant() {
    const [log, setLog] = useState([{ r: "a", t: 'Try: "How much did I spend on food?", "Mera balance kitna hai?", "forecast"' }]), [q, setQ] = useState(""), [lang, setLang] = useState("en-IN");
    const send = async (text) => {
        if (!text.trim())
            return;
        setLog((l) => [...l, { r: "u", t: text }]);
        setQ("");
        const r = await post("/chat", { message: text });
        setLog((l) => [...l, { r: "a", t: r.reply }]);
        try {
            const u = new SpeechSynthesisUtterance(r.reply);
            u.lang = lang;
            speechSynthesis.speak(u);
        }
        catch { }
    };
    const mic = () => { const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR)
        return alert("Voice input is not supported in this browser."); const r = new SR(); r.lang = lang; r.onresult = (e) => send(e.results[0][0].transcript); r.start(); };
    return (_jsxs(Card, { t: "AI financial assistant (English / \u0939\u093F\u0928\u094D\u0926\u0940 / Hinglish)", children: [_jsx("div", { className: "h-80 overflow-y-auto flex flex-col gap-2 mb-3", children: log.map((m, i) => _jsx("div", { className: "px-3 py-2 rounded-xl max-w-[85%] " + (m.r === "u" ? "self-end bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-700"), children: m.t }, i)) }), _jsxs("div", { className: "flex gap-2", children: [_jsxs("select", { className: inp, value: lang, onChange: (e) => setLang(e.target.value), children: [_jsx("option", { value: "en-IN", children: "English" }), _jsx("option", { value: "hi-IN", children: "\u0939\u093F\u0928\u094D\u0926\u0940" })] }), _jsx("button", { className: inp, onClick: mic, children: "\uD83C\uDFA4" }), _jsx("input", { className: inp + " flex-1", value: q, onChange: (e) => setQ(e.target.value), onKeyDown: (e) => e.key === "Enter" && send(q), placeholder: "Ask about your money\u2026" }), _jsx("button", { className: btn, onClick: () => send(q), children: "Send" })] })] }));
}
function Settings({ onLogout }) {
    const [p, setP] = useState(null);
    useEffect(() => { api("/me").then(setP); }, []);
    const csv = async () => { const t = await api("/export/csv"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([t], { type: "text/csv" })); a.download = "smartfin.csv"; a.click(); };
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { t: "Preferences", children: [p && _jsxs("div", { className: "flex gap-2 items-center", children: ["Low-balance alert \u20B9", _jsx("input", { className: inp + " w-32", type: "number", defaultValue: p.low_balance, onBlur: (e) => api("/me", { method: "PUT", body: JSON.stringify({ low_balance: +e.target.value }) }) })] }), _jsxs("p", { className: "text-sm text-slate-500 mt-2", children: ["Currency: INR (\u20B9). Signed in as ", p?.email, "."] })] }), _jsxs(Card, { t: "Reports", children: [_jsx("button", { className: btn, onClick: csv, children: "Download CSV" }), " ", _jsx("button", { className: btn, onClick: () => window.print(), children: "Print / Save as PDF" })] }), _jsx(Card, { t: "Account", children: _jsx("button", { className: "rounded-lg border border-red-500 text-red-500 px-3 py-1.5", onClick: async () => { if (confirm("Permanently delete your account and all data?")) {
                        await api("/me", { method: "DELETE" });
                        tok.clear();
                        onLogout();
                    } }, children: "Delete account & data" }) })] }));
}
const PAGES = ["Dashboard", "Transactions", "Insights", "Budgets", "Simulator", "Assistant", "Settings"];
export default function App() {
    const [authed, setAuthed] = useState(!!tok.get()), [page, setPage] = useState("Dashboard"), [dark, setDark] = useState(matchMedia("(prefers-color-scheme: dark)").matches);
    useEffect(() => { document.documentElement.classList.toggle("dark", dark); }, [dark]);
    if (!authed)
        return _jsx(Auth, { onDone: () => setAuthed(true) });
    const out = () => { tok.clear(); setAuthed(false); };
    return (_jsxs("div", { className: "max-w-5xl mx-auto p-4", children: [_jsxs("header", { className: "flex items-center gap-3 mb-4 print:hidden", children: [_jsx("span", { className: "font-extrabold text-lg bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent", children: "\u25C6 SmartFin AI" }), _jsx("nav", { className: "flex gap-1 overflow-x-auto flex-1", children: PAGES.map((p) => _jsx("button", { onClick: () => setPage(p), className: "px-3 py-1.5 rounded-lg whitespace-nowrap " + (page === p ? "bg-indigo-600 text-white" : "hover:bg-slate-200 dark:hover:bg-slate-700"), children: p }, p)) }), _jsx("button", { onClick: () => setDark(!dark), children: "\u25D0" }), _jsx("button", { className: "text-sm", onClick: out, children: "Logout" })] }), page === "Dashboard" && _jsx(Dashboard, {}), page === "Transactions" && _jsx(Transactions, {}), page === "Insights" && _jsx(Insights, {}), page === "Budgets" && _jsx(Budgets, {}), page === "Simulator" && _jsx(Simulator, {}), page === "Assistant" && _jsx(Assistant, {}), page === "Settings" && _jsx(Settings, { onLogout: out })] }));
}
