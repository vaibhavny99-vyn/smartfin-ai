const rawBase = import.meta.env.VITE_API ?? (import.meta.env.DEV ? "http://localhost:8000" : "");
export const BASE = (rawBase && !rawBase.startsWith("http://") && !rawBase.startsWith("https://") && !rawBase.startsWith("/"))
    ? "https://" + rawBase
    : rawBase;
export const tok = { get: () => localStorage.getItem("sf_token"), set: (t) => localStorage.setItem("sf_token", t), clear: () => localStorage.removeItem("sf_token") };
export async function api(path, opt = {}) {
    const isForm = opt.body instanceof FormData;
    const r = await fetch(BASE + path, { ...opt, headers: { ...(isForm ? {} : { "Content-Type": "application/json" }), ...(tok.get() ? { Authorization: "Bearer " + tok.get() } : {}) } });
    if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        throw new Error(typeof e.detail === "string" ? e.detail : r.statusText);
    }
    return (r.headers.get("content-type") || "").includes("json") ? r.json() : (await r.text());
}
export const post = (p, b) => api(p, { method: "POST", body: JSON.stringify(b) });
